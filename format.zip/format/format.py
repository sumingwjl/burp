import getopt
import sys

import pandas as pd
import numpy as np
from pandas import DataFrame


def find_same(vul, vul_list):
    i = 0
    if len(vul_list) == 0:
        return -1
    for v in vul_list:
        if vul == v:
            return i
        i += 1
    return -1

def deal_file(origin_file, target_file, app_name):
    df = pd.read_csv(origin_file)
    # 获取列名
    column_names = df.columns.tolist()
    # 重新排序列
    new_column_order = ["Main ID", "Detailed ID", "Priority", "Application Name", "Vulnerability Name",
                        "Affected IP Range", "Impact", "Recommended Remediation", "Description", "Reference", "CVE ID"]
    # 需要从CSV报告中提取的列的名称
    target_cols = ["CVE", "Risk", "Host", "Port", "Name", "Synopsis", "Description", "Solution", "See Also", "BID", "XREF", "MSKB"]
    # 目标列的位置
    target_cols_index = []
    for col in target_cols:
        index = 0
        for origin_col in column_names:
            if col.lower() == origin_col.lower():
                break
            index += 1
        if index >= len(column_names):
            print("Don't found " + col + " column in csv file. Please check it.")
            return 0
        target_cols_index.append(index)

    data = {}
    main_id = []
    detail_id = []
    priority = []
    app_names = []
    v_name = []
    a_ip_range = []
    impact = []
    recommend = []
    description = []
    reference = []
    cve_id = []
    # 先过滤风险等级为info的
    for i in range(len(df)):
        risk_index = target_cols_index[1]
        risk = df[column_names[risk_index]][i]

        if risk.lower() == 'none' or pd.isnull(risk):
            continue
        main_id.append(" ")
        detail_id.append(" ")
        if risk.lower() == 'high' or risk.lower() == 'critical':
            priority.append("Priority 1")
        elif risk.lower() == 'medium':
            priority.append("Priority 2")
        else:
            priority.append("Priority 3")

        app_names.append(app_name)

        host_index = target_cols_index[2]
        port_index = target_cols_index[3]
        port = str(df[column_names[port_index]][i])
        t_ip = df[column_names[host_index]][i] + ":" + port
        a_ip_range.append(t_ip)

        v_name_index = target_cols_index[4]
        v_name.append(df[column_names[v_name_index]][i])

        impact_index = target_cols_index[5]
        impact.append(df[column_names[impact_index]][i])

        recommend_index = target_cols_index[7]
        recommend.append(df[column_names[recommend_index]][i])

        desc_index = target_cols_index[6]
        description.append(df[column_names[desc_index]][i])

        bid_index = target_cols_index[9]
        bid = df[column_names[bid_index]][i]

        xref_index = target_cols_index[10]
        xref = df[column_names[xref_index]][i]

        mskb_index = target_cols_index[11]
        mskb = df[column_names[mskb_index]][i]
        ref = ""
        if bid != "" and pd.isnull(bid) is False:
            ref += "BID    " + bid + '\n'
        if xref != "" and pd.isnull(xref) is False:
            ref += "XREF    " + xref + '\n'
        if mskb != "" and pd.isnull(mskb) is False:
            ref += "mskb    " + mskb
        reference.append(ref)

        cve_index = target_cols_index[0]
        cve_id.append(df[column_names[cve_index]][i])
    # 2、跟据漏洞名称对结果做整合
    unique_vul = []
    main1_id = []
    detail1_id = []
    priority1 = []
    app1_names = []
    a1_ip_range = []
    impact1 = []
    recommend1 = []
    description1 = []
    reference1 = []
    cve_id1 = []
    i = 0
    for vul_name in v_name:
        index = find_same(vul_name, unique_vul)
        if index >= 0:   # 已经记录过了,将ip_range合成一条数据，用逗号分隔
            a1_ip_range[index] = a1_ip_range[index] + ',' + a_ip_range[i]
        else:   # 该漏洞还没有记录过
            unique_vul.append(vul_name)
            main1_id.append("")
            detail1_id.append("")
            priority1.append(priority[i])
            a1_ip_range.append(a_ip_range[i])
            app1_names.append(app_names[i])
            impact1.append(impact[i])
            recommend1.append(recommend[i])
            description1.append(description[i])
            reference1.append(reference[i])
            cve_id1.append(cve_id[i])
        i += 1

    # 3、将结果进行整合并写入到新文件中
    vule_list = []
    vule_list.append(main1_id)
    vule_list.append(detail1_id)
    vule_list.append(priority1)
    vule_list.append(app1_names)
    vule_list.append(unique_vul)
    vule_list.append(a1_ip_range)
    vule_list.append(impact1)
    vule_list.append(recommend1)
    vule_list.append(description1)
    vule_list.append(reference1)
    vule_list.append(cve_id1)
    i = 0
    while i < len(new_column_order):
        data[new_column_order[i]] = vule_list[i]
        i += 1
    df_new = DataFrame(data)
    df_new.to_excel(target_file)


if __name__ == '__main__':
    csv_file = ''
    xlsx_file = ''
    app_name = ''
    try:
        """
            options, args = getopt.getopt(args, shortopts, longopts=[])

            参数args：一般是sys.argv[1:]。过滤掉sys.argv[0]，它是执行脚本的名字，不算做命令行参数。
            参数shortopts：短格式分析串。例如："hp:i:"，h后面没有冒号，表示后面不带参数；p和i后面带有冒号，表示后面带参数。
            参数longopts：长格式分析串列表。例如：["help", "ip=", "port="]，help后面没有等号，表示后面不带参数；ip和port后面带冒号，表示后面带参数。

            返回值options是以元组为元素的列表，每个元组的形式为：(选项串, 附加参数)，如：('-i', '192.168.0.1')
            返回值args是个列表，其中的元素是那些不含'-'或'--'的参数。
        """
        print(len(sys.argv))
        opts, args = getopt.getopt(sys.argv[1:], "ho:t:n:", ["help", "origin=", "target=", "name="])
    except getopt.GetoptError:
        print('Error: test_arg.py -o <Nessus CSV report file path> -t <output/target file path> -n <Application name>')
        print('or: test_arg.py --origin=<Nessus CSV report file path> --target=<output/target file path> --name '
              '<Application name>')
        sys.exit(2)
    for opt, arg in opts:
        if opt in ("-h", "--help"):
            print('format.py -o <Nessus CSV report file path> -t <output/target file path> -n <Application name>')
            print('or: format.py --origin=<Nessus CSV report file path> --target=<output/target file path> --name '
                  '<Application Name>')
            sys.exit()
        elif opt in ("-o", "--origin"):
            csv_file = arg
        elif opt in ("-t", "--target"):
            xlsx_file = arg
        elif opt in ("-n", "--name"):
            app_name = arg
    # 读取CSV文件
    csv_file = 'test.csv'  # 替换成你的CSV文件路径
    # 写入XLSX文件
    xlsx_file = 'output.xlsx'  # 替换成你想要保存的XLSX文件路径
    deal_file(csv_file, xlsx_file, app_name)
